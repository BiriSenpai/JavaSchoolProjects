import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Scanner;
import java.lang.Integer;
public class Jedis {
		public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			int numf=0;
			int fuerza = 0;
			int res = 0;
			String datos= "a";
			List<Integer> Lres = new ArrayList<Integer>();
			System.out.println("Dime el numero de familias: ");
			numf =input.nextInt();
			for (int i=1; i<= numf; i++) {
				System.out.println(i);
				System.out.println("Dime cuantos hijos tienes y el numero de midiclorianos que trasnmitis: (separa los datos por un espacio)");
				datos=input.nextLine();
				System.out.println(datos);
				/*String[] lista = datos.split(" ");
				//System.out.println(lista[1]);
				int numh = Integer.parseInt(lista[0]);
				int infl = Integer.parseInt(lista[1]);
				for (int x=0; x < numh; x++) {
					System.out.println("Introduce la influencia de la fuerza el dia del nacimiento del ni�o/a");
					fuerza = input.nextInt();
					res = fuerza*infl;
					Lres.add(res);
					
				}*/
			
			//System.out.println(Lres);
		}
	}
}

